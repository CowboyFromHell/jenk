#!/bin/sh
aws s3 cp dist/trains.zip s3://mydoombucket666
